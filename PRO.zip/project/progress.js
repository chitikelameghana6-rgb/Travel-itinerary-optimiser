import { getSubjects } from './subjects.js'
import { getTaskStats } from './tasks.js'

export function getOverallProgress() {
  const subjects = getSubjects()
  if (subjects.length === 0) return 0
  const total = subjects.reduce((sum, s) => sum + s.progress, 0)
  return Math.round(total / subjects.length)
}

export function getTaskCompletionRate() {
  const stats = getTaskStats()
  if (stats.total === 0) return 0
  return Math.round((stats.completed / stats.total) * 100)
}

export function getProgressRingSVG(percent) {
  const radius = 70
  const circumference = 2 * Math.PI * radius
  const offset = circumference - (percent / 100) * circumference
  return `
    <svg width="180" height="180" viewBox="0 0 180 180">
      <circle class="progress-ring-bg" cx="90" cy="90" r="${radius}" />
      <circle class="progress-ring-fill" cx="90" cy="90" r="${radius}"
        stroke-dasharray="${circumference}"
        stroke-dashoffset="${offset}" />
    </svg>
  `
}
