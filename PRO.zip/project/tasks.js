import { loadData, saveData, uid } from './storage.js'

let tasks = []
let currentFilter = 'all'
let currentSearch = ''
let subjects = []

export function initTasks(subjectsList) {
  subjects = subjectsList
  tasks = loadData('tasks', [])
}

export function getTasks() {
  return tasks
}

export function saveTasks() {
  saveData('tasks', tasks)
}

export function addTask(task) {
  tasks.unshift({
    id: uid(),
    title: task.title,
    subject: task.subject || '',
    priority: task.priority || 'medium',
    dueDate: task.dueDate || '',
    completed: false,
    createdAt: Date.now(),
  })
  saveTasks()
}

export function updateTask(id, updates) {
  const task = tasks.find((t) => t.id === id)
  if (task) {
    Object.assign(task, updates)
    saveTasks()
  }
}

export function deleteTask(id) {
  tasks = tasks.filter((t) => t.id !== id)
  saveTasks()
}

export function toggleTask(id) {
  const task = tasks.find((t) => t.id === id)
  if (task) {
    task.completed = !task.completed
    saveTasks()
  }
}

export function getFilteredTasks() {
  return tasks.filter((t) => {
    const matchesSearch =
      !currentSearch ||
      t.title.toLowerCase().includes(currentSearch) ||
      (t.subject || '').toLowerCase().includes(currentSearch)

    const matchesFilter =
      currentFilter === 'all' ||
      (currentFilter === 'active' && !t.completed) ||
      (currentFilter === 'completed' && t.completed) ||
      (currentFilter === 'high' && t.priority === 'high')

    return matchesSearch && matchesFilter
  })
}

export function setFilter(filter) {
  currentFilter = filter
}

export function setSearch(search) {
  currentSearch = search.toLowerCase()
}

export function getTaskStats() {
  const total = tasks.length
  const completed = tasks.filter((t) => t.completed).length
  const active = total - completed
  const highPriority = tasks.filter((t) => t.priority === 'high' && !t.completed).length
  return { total, completed, active, highPriority }
}
