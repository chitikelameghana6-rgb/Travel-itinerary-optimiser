import { loadData, saveData, uid } from './storage.js'

const COLORS = ['blue', 'teal', 'amber', 'rose', 'violet', 'emerald', 'sky', 'orange']

let subjects = []

const defaultSubjects = [
  { id: uid(), name: 'Mathematics', code: 'MATH101', hours: 12, progress: 65, color: 'blue' },
  { id: uid(), name: 'Physics', code: 'PHY102', hours: 8, progress: 40, color: 'teal' },
  { id: uid(), name: 'Computer Science', code: 'CS201', hours: 15, progress: 80, color: 'amber' },
  { id: uid(), name: 'English Literature', code: 'ENG150', hours: 5, progress: 55, color: 'rose' },
]

export function initSubjects() {
  subjects = loadData('subjects', defaultSubjects)
  saveSubjects()
  return subjects
}

export function getSubjects() {
  return subjects
}

export function saveSubjects() {
  saveData('subjects', subjects)
}

export function addSubject(subject) {
  const colorIndex = subjects.length % COLORS.length
  subjects.push({
    id: uid(),
    name: subject.name,
    code: subject.code || '',
    hours: parseInt(subject.hours) || 0,
    progress: parseInt(subject.progress) || 0,
    color: subject.color || COLORS[colorIndex],
  })
  saveSubjects()
}

export function updateSubject(id, updates) {
  const subject = subjects.find((s) => s.id === id)
  if (subject) {
    Object.assign(subject, updates)
    saveSubjects()
  }
}

export function deleteSubject(id) {
  subjects = subjects.filter((s) => s.id !== id)
  saveSubjects()
}

export function getSubjectNames() {
  return subjects.map((s) => s.name)
}

export function getColorOptions() {
  return COLORS
}
