import './style.css'
import { initSubjects, getSubjects, addSubject, updateSubject, deleteSubject, getSubjectNames, getColorOptions } from './subjects.js'
import { initTasks, getTasks, addTask, updateTask, deleteTask, toggleTask, setFilter, setSearch, getFilteredTasks, getTaskStats } from './tasks.js'
import { initTimetable, getSchedule, addEntry, removeEntry, getEntry, getDays, getTimeSlots } from './timetable.js'
import { getOverallProgress, getTaskCompletionRate, getProgressRingSVG } from './progress.js'

/* ===== State ===== */
let currentSection = 'home'
let editingTaskId = null
let editingSubjectId = null

/* ===== Init ===== */
function init() {
  initTheme()
  const subjects = initSubjects()
  initTasks(subjects)
  initTimetable()
  renderApp()
  bindNavigation()
  bindGlobalActions()
}

/* ===== Theme ===== */
function initTheme() {
  const saved = localStorage.getItem('studyPlanner:theme') || 'light'
  document.documentElement.setAttribute('data-theme', saved)
}

function toggleTheme() {
  const current = document.documentElement.getAttribute('data-theme')
  const next = current === 'light' ? 'dark' : 'light'
  document.documentElement.setAttribute('data-theme', next)
  localStorage.setItem('studyPlanner:theme', next)
  updateThemeIcon(next)
}

function updateThemeIcon(theme) {
  const icon = document.querySelector('.theme-toggle')
  if (icon) icon.textContent = theme === 'light' ? '\u{1F319}' : '\u2600\uFE0F'
}

/* ===== Render App Shell ===== */
function renderApp() {
  const app = document.querySelector('#app')
  app.innerHTML = `
    <nav class="navbar">
      <div class="nav-container">
        <div class="nav-logo">
          <span class="nav-logo-icon">\u{1F4D6}</span>
          <span>Study Planner</span>
        </div>
        <ul class="nav-links" id="navLinks">
          <li><button class="nav-link active" data-section="home">Home</button></li>
          <li><button class="nav-link" data-section="tasks">Tasks</button></li>
          <li><button class="nav-link" data-section="timetable">Timetable</button></li>
          <li><button class="nav-link" data-section="subjects">Subjects</button></li>
          <li><button class="nav-link" data-section="progress">Progress</button></li>
        </ul>
        <div class="nav-actions">
          <button class="theme-toggle" id="themeToggle" title="Toggle theme"></button>
          <button class="nav-toggle" id="navToggle"><span></span><span></span><span></span></button>
        </div>
      </div>
    </nav>
    <main class="main-content">
      <section class="section active" id="section-home"></section>
      <section class="section" id="section-tasks"></section>
      <section class="section" id="section-timetable"></section>
      <section class="section" id="section-subjects"></section>
      <section class="section" id="section-progress"></section>
    </main>
    <div class="modal-overlay" id="modalOverlay">
      <div class="modal" id="modalContent"></div>
    </div>
    <div class="toast" id="toast"></div>
  `
  updateThemeIcon(document.documentElement.getAttribute('data-theme'))
  renderAllSections()
}

function renderAllSections() {
  renderDashboard()
  renderTasks()
  renderTimetable()
  renderSubjects()
  renderProgress()
}

/* ===== Navigation ===== */
function bindNavigation() {
  document.querySelectorAll('.nav-link').forEach((link) => {
    link.addEventListener('click', () => {
      const section = link.dataset.section
      switchSection(section)
    })
  })

  document.getElementById('navToggle').addEventListener('click', () => {
    document.getElementById('navLinks').classList.toggle('open')
  })
}

function switchSection(section) {
  currentSection = section
  document.querySelectorAll('.nav-link').forEach((l) => {
    l.classList.toggle('active', l.dataset.section === section)
  })
  document.querySelectorAll('.section').forEach((s) => {
    s.classList.toggle('active', s.id === 'section-' + section)
  })
  document.getElementById('navLinks').classList.remove('open')

  if (section === 'home') renderDashboard()
  if (section === 'tasks') renderTasks()
  if (section === 'timetable') renderTimetable()
  if (section === 'subjects') renderSubjects()
  if (section === 'progress') renderProgress()
}

function bindGlobalActions() {
  document.addEventListener('click', (e) => {
    if (e.target.id === 'themeToggle') toggleTheme()
    if (e.target.id === 'modalOverlay') closeModal()
  })
}

/* ===== Dashboard ===== */
function renderDashboard() {
  const stats = getTaskStats()
  const overall = getOverallProgress()
  const taskRate = getTaskCompletionRate()
  const today = new Date().toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  })

  const completionDisplay = stats.total > 0 ? `${stats.completed}/${stats.total}` : '0/0'

  document.getElementById('section-home').innerHTML = `
    <div class="section-header">
      <div class="dashboard-date">\u{1F4C5} ${today}</div>
      <h1 class="section-title">Dashboard</h1>
      <p class="section-subtitle">Your study overview at a glance</p>
    </div>
    <div class="stats-grid">
      <div class="stat-card">
        <div class="stat-icon primary">\u{1F4DD}</div>
        <div class="stat-value">${stats.total}</div>
        <div class="stat-label">Total Tasks</div>
      </div>
      <div class="stat-card success">
        <div class="stat-icon success">\u2705</div>
        <div class="stat-value">${stats.completed}</div>
        <div class="stat-label">Completed Tasks</div>
      </div>
      <div class="stat-card accent">
        <div class="stat-icon accent">\u23F3</div>
        <div class="stat-value">${stats.active}</div>
        <div class="stat-label">Active Tasks</div>
      </div>
      <div class="stat-card secondary">
        <div class="stat-icon secondary">\u{1F4CA}</div>
        <div class="stat-value">${overall}%</div>
        <div class="stat-label">Study Progress</div>
      </div>
    </div>
    <div class="dashboard-progress-card">
      <h3>Overall Study Progress</h3>
      <div class="overall-progress-bar">
        <div class="overall-progress-fill" style="width: ${overall}%"></div>
      </div>
      <p class="overall-progress-text">Average progress across ${getSubjects().length} subjects</p>
    </div>
  `
}

/* ===== Tasks ===== */
function renderTasks() {
  const filtered = getFilteredTasks()
  const subjectNames = getSubjectNames()

  document.getElementById('section-tasks').innerHTML = `
    <div class="section-header">
      <h1 class="section-title">Tasks</h1>
      <p class="section-subtitle">Manage your study tasks and stay on track</p>
    </div>
    <div class="task-controls">
      <div class="search-box">
        <span class="search-icon">\u{1F50D}</span>
        <input type="text" class="search-input" id="taskSearch" placeholder="Search tasks..." value="${getCurrentSearchValue()}">
      </div>
      <select class="filter-select" id="taskFilter">
        <option value="all">All Tasks</option>
        <option value="active">Active</option>
        <option value="completed">Completed</option>
        <option value="high">High Priority</option>
      </select>
      <button class="btn btn-primary" id="addTaskBtn">+ Add Task</button>
    </div>
    <div class="task-list" id="taskList">
      ${filtered.length === 0 ? renderEmptyTasks() : filtered.map(renderTaskItem).join('')}
    </div>
  `

  bindTaskEvents()
}

function renderEmptyTasks() {
  return `
    <div class="empty-state">
      <div class="empty-state-icon">\u{1F4CB}</div>
      <p class="empty-state-text">No tasks found. Click "Add Task" to get started!</p>
    </div>
  `
}

function renderTaskItem(task) {
  const isOverdue = task.dueDate && !task.completed && new Date(task.dueDate) < new Date(new Date().toDateString())
  return `
    <div class="task-item ${task.completed ? 'completed' : ''}" data-id="${task.id}">
      <div class="task-checkbox ${task.completed ? 'checked' : ''}" data-action="toggle" data-id="${task.id}">
        ${task.completed ? '\u2713' : ''}
      </div>
      <div class="task-content">
        <div class="task-title">${escapeHtml(task.title)}</div>
        <div class="task-meta">
          ${task.subject ? `<span class="task-badge subject">${escapeHtml(task.subject)}</span>` : ''}
          ${task.priority ? `<span class="task-badge priority-${task.priority}">${task.priority.charAt(0).toUpperCase() + task.priority.slice(1)} Priority</span>` : ''}
          ${task.dueDate ? `<span class="task-badge ${isOverdue ? 'overdue' : 'due'}">\u{1F4C5} ${formatDate(task.dueDate)}${isOverdue ? ' (Overdue)' : ''}</span>` : ''}
        </div>
      </div>
      <div class="task-actions">
        <button class="btn-icon" data-action="edit" data-id="${task.id}" title="Edit">\u270E</button>
        <button class="btn-icon danger" data-action="delete" data-id="${task.id}" title="Delete">\u{1F5D1}</button>
      </div>
    </div>
  `
}

function bindTaskEvents() {
  const searchInput = document.getElementById('taskSearch')
  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      setSearch(e.target.value)
      renderTaskListOnly()
    })
  }

  const filterSelect = document.getElementById('taskFilter')
  if (filterSelect) {
    filterSelect.value = getCurrentFilterValue()
    filterSelect.addEventListener('change', (e) => {
      setFilter(e.target.value)
      renderTaskListOnly()
    })
  }

  const addBtn = document.getElementById('addTaskBtn')
  if (addBtn) {
    addBtn.addEventListener('click', () => {
      editingTaskId = null
      openTaskModal()
    })
  }

  document.querySelectorAll('[data-action="toggle"]').forEach((el) => {
    el.addEventListener('click', () => {
      toggleTask(el.dataset.id)
      renderTaskListOnly()
      renderDashboard()
      renderProgress()
      showToast('Task updated', 'info')
    })
  })

  document.querySelectorAll('[data-action="edit"]').forEach((el) => {
    el.addEventListener('click', () => {
      editingTaskId = el.dataset.id
      openTaskModal()
    })
  })

  document.querySelectorAll('[data-action="delete"]').forEach((el) => {
    el.addEventListener('click', () => {
      deleteTask(el.dataset.id)
      renderTaskListOnly()
      renderDashboard()
      renderProgress()
      showToast('Task deleted', 'error')
    })
  })
}

function renderTaskListOnly() {
  const list = document.getElementById('taskList')
  if (!list) return
  const filtered = getFilteredTasks()
  list.innerHTML = filtered.length === 0 ? renderEmptyTasks() : filtered.map(renderTaskItem).join('')
  bindTaskListEvents()
}

function bindTaskListEvents() {
  document.querySelectorAll('[data-action="toggle"]').forEach((el) => {
    el.addEventListener('click', () => {
      toggleTask(el.dataset.id)
      renderTaskListOnly()
      renderDashboard()
      renderProgress()
    })
  })
  document.querySelectorAll('[data-action="edit"]').forEach((el) => {
    el.addEventListener('click', () => {
      editingTaskId = el.dataset.id
      openTaskModal()
    })
  })
  document.querySelectorAll('[data-action="delete"]').forEach((el) => {
    el.addEventListener('click', () => {
      deleteTask(el.dataset.id)
      renderTaskListOnly()
      renderDashboard()
      renderProgress()
      showToast('Task deleted', 'error')
    })
  })
}

function openTaskModal() {
  const tasks = getTasks()
  const task = editingTaskId ? tasks.find((t) => t.id === editingTaskId) : null
  const subjectNames = getSubjectNames()

  const modalContent = document.getElementById('modalContent')
  modalContent.innerHTML = `
    <div class="modal-header">
      <h2 class="modal-title">${task ? 'Edit Task' : 'Add New Task'}</h2>
      <button class="modal-close" id="modalClose">&times;</button>
    </div>
    <form id="taskForm">
      <div class="form-group">
        <label class="form-label">Task Title *</label>
        <input type="text" class="form-input" id="taskTitle" required value="${task ? escapeHtml(task.title) : ''}" placeholder="e.g. Complete Chapter 5 exercises">
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Subject</label>
          <select class="form-select" id="taskSubject">
            <option value="">No subject</option>
            ${subjectNames.map((s) => `<option value="${escapeHtml(s)}" ${task && task.subject === s ? 'selected' : ''}>${escapeHtml(s)}</option>`).join('')}
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Priority</label>
          <select class="form-select" id="taskPriority">
            <option value="low" ${task && task.priority === 'low' ? 'selected' : ''}>Low</option>
            <option value="medium" ${(!task || task.priority === 'medium') ? 'selected' : ''}>Medium</option>
            <option value="high" ${task && task.priority === 'high' ? 'selected' : ''}>High</option>
          </select>
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">Due Date</label>
        <input type="date" class="form-input" id="taskDueDate" value="${task ? task.dueDate : ''}">
      </div>
      <div class="modal-actions">
        <button type="button" class="btn btn-secondary" id="modalCancel">Cancel</button>
        <button type="submit" class="btn btn-primary">${task ? 'Update' : 'Add'} Task</button>
      </div>
    </form>
  `

  openModal()

  document.getElementById('modalClose').addEventListener('click', closeModal)
  document.getElementById('modalCancel').addEventListener('click', closeModal)
  document.getElementById('taskForm').addEventListener('submit', (e) => {
    e.preventDefault()
    const data = {
      title: document.getElementById('taskTitle').value.trim(),
      subject: document.getElementById('taskSubject').value,
      priority: document.getElementById('taskPriority').value,
      dueDate: document.getElementById('taskDueDate').value,
    }
    if (!data.title) return

    if (editingTaskId) {
      updateTask(editingTaskId, data)
      showToast('Task updated', 'success')
    } else {
      addTask(data)
      showToast('Task added', 'success')
    }
    closeModal()
    renderTaskListOnly()
    renderDashboard()
    renderProgress()
  })
}

/* ===== Timetable ===== */
function renderTimetable() {
  const days = getDays()
  const slots = getTimeSlots()
  const schedule = getSchedule()
  const subjectNames = getSubjectNames()

  let html = `
    <div class="section-header">
      <h1 class="section-title">Weekly Timetable</h1>
      <p class="section-subtitle">Click an empty slot to add a study session. Click a filled slot to remove it.</p>
    </div>
    <div class="timetable-wrapper">
      <table class="timetable">
        <thead>
          <tr>
            <th>Time</th>
            ${days.map((d) => `<th>${d.slice(0, 3)}</th>`).join('')}
          </tr>
        </thead>
        <tbody>
  `

  for (const slot of slots) {
    html += `<tr><td>${slot}</td>`
    for (const day of days) {
      const entry = schedule.find((e) => e.day === day && e.slot === slot)
      if (entry) {
        html += `<td class="timetable-slot occupied" data-day="${day}" data-slot="${slot}" data-id="${entry.id}">${escapeHtml(entry.subject)}<div class="slot-delete" data-id="${entry.id}">Remove</div></td>`
      } else {
        html += `<td class="timetable-slot" data-day="${day}" data-slot="${slot}">+</td>`
      }
    }
    html += `</tr>`
  }

  html += `
        </tbody>
      </table>
    </div>
  `

  document.getElementById('section-timetable').innerHTML = html
  bindTimetableEvents(subjectNames)
}

function bindTimetableEvents(subjectNames) {
  document.querySelectorAll('.timetable-slot').forEach((slot) => {
    slot.addEventListener('click', (e) => {
      if (e.target.classList.contains('slot-delete')) {
        removeEntry(e.target.dataset.id)
        renderTimetable()
        showToast('Session removed', 'info')
        return
      }
      const day = slot.dataset.day
      const slotTime = slot.dataset.slot
      if (slot.classList.contains('occupied')) return
      openTimetableModal(day, slotTime, subjectNames)
    })
  })
}

function openTimetableModal(day, slot, subjectNames) {
  const modalContent = document.getElementById('modalContent')
  modalContent.innerHTML = `
    <div class="modal-header">
      <h2 class="modal-title">Add Study Session</h2>
      <button class="modal-close" id="modalClose">&times;</button>
    </div>
    <form id="timetableForm">
      <div class="form-group">
        <label class="form-label">Day</label>
        <input type="text" class="form-input" value="${day}" disabled>
      </div>
      <div class="form-group">
        <label class="form-label">Time Slot</label>
        <input type="text" class="form-input" value="${slot}" disabled>
      </div>
      <div class="form-group">
        <label class="form-label">Subject *</label>
        <select class="form-select" id="timetableSubject" required>
          <option value="">Select a subject</option>
          ${subjectNames.map((s) => `<option value="${escapeHtml(s)}">${escapeHtml(s)}</option>`).join('')}
        </select>
      </div>
      <div class="modal-actions">
        <button type="button" class="btn btn-secondary" id="modalCancel">Cancel</button>
        <button type="submit" class="btn btn-primary">Add Session</button>
      </div>
    </form>
  `

  openModal()

  document.getElementById('modalClose').addEventListener('click', closeModal)
  document.getElementById('modalCancel').addEventListener('click', closeModal)
  document.getElementById('timetableForm').addEventListener('submit', (e) => {
    e.preventDefault()
    const subject = document.getElementById('timetableSubject').value
    if (!subject) return
    addEntry(day, slot, subject)
    closeModal()
    renderTimetable()
    showToast('Session added', 'success')
  })
}

/* ===== Subjects ===== */
function renderSubjects() {
  const subjects = getSubjects()

  document.getElementById('section-subjects').innerHTML = `
    <div class="section-header">
      <h1 class="section-title">Subjects</h1>
      <p class="section-subtitle">Track your subjects and study hours</p>
    </div>
    <div style="margin-bottom: var(--spacing-3);">
      <button class="btn btn-primary" id="addSubjectBtn">+ Add Subject</button>
    </div>
    <div class="subjects-grid" id="subjectsGrid">
      ${subjects.length === 0 ? '<div class="empty-state"><div class="empty-state-icon">\u{1F4DA}</div><p class="empty-state-text">No subjects yet. Add one to get started!</p></div>' : subjects.map(renderSubjectCard).join('')}
    </div>
  `

  bindSubjectEvents()
}

function renderSubjectCard(subject) {
  return `
    <div class="subject-card" data-color="${subject.color}" data-id="${subject.id}">
      <div class="subject-header">
        <div>
          <div class="subject-name">${escapeHtml(subject.name)}</div>
          ${subject.code ? `<span class="subject-code">${escapeHtml(subject.code)}</span>` : ''}
        </div>
        <div style="display:flex; gap:4px;">
          <button class="btn-icon" data-action="edit-subject" data-id="${subject.id}" title="Edit">\u270E</button>
          <button class="btn-icon danger" data-action="delete-subject" data-id="${subject.id}" title="Delete">\u{1F5D1}</button>
        </div>
      </div>
      <div class="subject-hours">
        <span class="subject-hours-value">${subject.hours}</span>
        <span class="subject-hours-label">hours studied</span>
      </div>
      <div class="subject-progress-label">
        <span>Progress</span>
        <span>${subject.progress}%</span>
      </div>
      <div class="subject-progress-bar">
        <div class="subject-progress-fill" style="width: ${subject.progress}%"></div>
      </div>
    </div>
  `
}

function bindSubjectEvents() {
  const addBtn = document.getElementById('addSubjectBtn')
  if (addBtn) {
    addBtn.addEventListener('click', () => {
      editingSubjectId = null
      openSubjectModal()
    })
  }

  document.querySelectorAll('[data-action="edit-subject"]').forEach((el) => {
    el.addEventListener('click', () => {
      editingSubjectId = el.dataset.id
      openSubjectModal()
    })
  })

  document.querySelectorAll('[data-action="delete-subject"]').forEach((el) => {
    el.addEventListener('click', () => {
      deleteSubject(el.dataset.id)
      renderSubjects()
      renderDashboard()
      renderProgress()
      showToast('Subject deleted', 'error')
    })
  })
}

function openSubjectModal() {
  const subjects = getSubjects()
  const subject = editingSubjectId ? subjects.find((s) => s.id === editingSubjectId) : null
  const colors = getColorOptions()

  const modalContent = document.getElementById('modalContent')
  modalContent.innerHTML = `
    <div class="modal-header">
      <h2 class="modal-title">${subject ? 'Edit Subject' : 'Add New Subject'}</h2>
      <button class="modal-close" id="modalClose">&times;</button>
    </div>
    <form id="subjectForm">
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Subject Name *</label>
          <input type="text" class="form-input" id="subjectName" required value="${subject ? escapeHtml(subject.name) : ''}" placeholder="e.g. Biology">
        </div>
        <div class="form-group">
          <label class="form-label">Course Code</label>
          <input type="text" class="form-input" id="subjectCode" value="${subject ? escapeHtml(subject.code) : ''}" placeholder="e.g. BIO101">
        </div>
      </div>
      <div class="form-row">
        <div class="form-group">
          <label class="form-label">Study Hours</label>
          <input type="number" class="form-input" id="subjectHours" min="0" value="${subject ? subject.hours : 0}">
        </div>
        <div class="form-group">
          <label class="form-label">Progress (%)</label>
          <input type="number" class="form-input" id="subjectProgress" min="0" max="100" value="${subject ? subject.progress : 0}">
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">Card Color</label>
        <select class="form-select" id="subjectColor">
          ${colors.map((c) => `<option value="${c}" ${subject && subject.color === c ? 'selected' : ''}>${c.charAt(0).toUpperCase() + c.slice(1)}</option>`).join('')}
        </select>
      </div>
      <div class="modal-actions">
        <button type="button" class="btn btn-secondary" id="modalCancel">Cancel</button>
        <button type="submit" class="btn btn-primary">${subject ? 'Update' : 'Add'} Subject</button>
      </div>
    </form>
  `

  openModal()

  document.getElementById('modalClose').addEventListener('click', closeModal)
  document.getElementById('modalCancel').addEventListener('click', closeModal)
  document.getElementById('subjectForm').addEventListener('submit', (e) => {
    e.preventDefault()
    const data = {
      name: document.getElementById('subjectName').value.trim(),
      code: document.getElementById('subjectCode').value.trim(),
      hours: parseInt(document.getElementById('subjectHours').value) || 0,
      progress: Math.min(100, Math.max(0, parseInt(document.getElementById('subjectProgress').value) || 0)),
      color: document.getElementById('subjectColor').value,
    }
    if (!data.name) return

    if (editingSubjectId) {
      updateSubject(editingSubjectId, data)
      showToast('Subject updated', 'success')
    } else {
      addSubject(data)
      showToast('Subject added', 'success')
    }
    closeModal()
    renderSubjects()
    renderDashboard()
    renderProgress()
  })
}

/* ===== Progress ===== */
function renderProgress() {
  const subjects = getSubjects()
  const overall = getOverallProgress()
  const taskRate = getTaskCompletionRate()
  const stats = getTaskStats()

  document.getElementById('section-progress').innerHTML = `
    <div class="section-header">
      <h1 class="section-title">Progress</h1>
      <p class="section-subtitle">Visualize your study progress and stay motivated</p>
    </div>
    <div class="progress-summary">
      <div class="stat-card">
        <div class="stat-icon primary">\u{1F4CA}</div>
        <div class="stat-value">${overall}%</div>
        <div class="stat-label">Overall Subject Progress</div>
      </div>
      <div class="stat-card success">
        <div class="stat-icon success">\u2705</div>
        <div class="stat-value">${taskRate}%</div>
        <div class="stat-label">Task Completion Rate</div>
      </div>
      <div class="stat-card accent">
        <div class="stat-icon accent">\u{1F4DD}</div>
        <div class="stat-value">${stats.completed}/${stats.total}</div>
        <div class="stat-label">Tasks Completed</div>
      </div>
      <div class="stat-card secondary">
        <div class="stat-icon secondary">\u{1F4DA}</div>
        <div class="stat-value">${subjects.length}</div>
        <div class="stat-label">Active Subjects</div>
      </div>
    </div>
    <div class="progress-cards">
      <div class="progress-card">
        <h3 class="progress-card-title">Subject Progress</h3>
        ${subjects.length === 0 ? '<p class="empty-state-text" style="color:var(--text-muted);">No subjects to display.</p>' : subjects.map((s) => `
          <div class="progress-item">
            <div class="progress-item-header">
              <span class="progress-item-name">${escapeHtml(s.name)}</span>
              <span class="progress-item-value">${s.progress}%</span>
            </div>
            <div class="subject-progress-bar">
              <div class="subject-progress-fill" style="width: ${s.progress}%; background: var(--primary);"></div>
            </div>
          </div>
        `).join('')}
      </div>
      <div class="progress-card">
        <h3 class="progress-card-title">Overall Completion</h3>
        <div class="progress-ring-wrapper">
          <div class="progress-ring">
            ${getProgressRingSVG(overall)}
            <div class="progress-ring-text">
              <div class="progress-ring-percent">${overall}%</div>
              <div class="progress-ring-label">Subject Progress</div>
            </div>
          </div>
          <div class="progress-ring" style="margin-top: var(--spacing-2);">
            ${getProgressRingSVG(taskRate)}
            <div class="progress-ring-text">
              <div class="progress-ring-percent">${taskRate}%</div>
              <div class="progress-ring-label">Tasks Done</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
}

/* ===== Modal Helpers ===== */
function openModal() {
  document.getElementById('modalOverlay').classList.add('active')
}

function closeModal() {
  document.getElementById('modalOverlay').classList.remove('active')
  editingTaskId = null
  editingSubjectId = null
}

/* ===== Toast ===== */
let toastTimer = null
function showToast(message, type = 'info') {
  const toast = document.getElementById('toast')
  if (!toast) return
  toast.textContent = message
  toast.className = `toast ${type} show`
  clearTimeout(toastTimer)
  toastTimer = setTimeout(() => {
    toast.classList.remove('show')
  }, 2500)
}

/* ===== Utilities ===== */
function escapeHtml(text) {
  if (!text) return ''
  const div = document.createElement('div')
  div.textContent = text
  return div.innerHTML
}

function formatDate(dateStr) {
  const d = new Date(dateStr)
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
}

function getCurrentSearchValue() {
  const input = document.getElementById('taskSearch')
  return input ? input.value : ''
}

function getCurrentFilterValue() {
  const select = document.getElementById('taskFilter')
  return select ? select.value : 'all'
}

/* ===== Start ===== */
init()
