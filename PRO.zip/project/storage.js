const PREFIX = 'studyPlanner:'

export function loadData(key, fallback) {
  try {
    const raw = localStorage.getItem(PREFIX + key)
    return raw ? JSON.parse(raw) : fallback
  } catch {
    return fallback
  }
}

export function saveData(key, data) {
  localStorage.setItem(PREFIX + key, JSON.stringify(data))
}

export function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8)
}
