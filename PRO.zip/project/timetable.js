import { loadData, saveData, uid } from './storage.js'

const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
const TIME_SLOTS = [
  '08:00 - 09:00',
  '09:00 - 10:00',
  '10:00 - 11:00',
  '11:00 - 12:00',
  '12:00 - 13:00',
  '14:00 - 15:00',
  '15:00 - 16:00',
  '16:00 - 17:00',
  '17:00 - 18:00',
  '19:00 - 20:00',
]

const defaultSchedule = [
  { id: uid(), day: 'Monday', slot: '08:00 - 09:00', subject: 'Mathematics' },
  { id: uid(), day: 'Monday', slot: '09:00 - 10:00', subject: 'Physics' },
  { id: uid(), day: 'Monday', slot: '14:00 - 15:00', subject: 'Computer Science' },
  { id: uid(), day: 'Tuesday', slot: '10:00 - 11:00', subject: 'English Literature' },
  { id: uid(), day: 'Tuesday', slot: '15:00 - 16:00', subject: 'Mathematics' },
  { id: uid(), day: 'Wednesday', slot: '09:00 - 10:00', subject: 'Physics' },
  { id: uid(), day: 'Wednesday', slot: '16:00 - 17:00', subject: 'Computer Science' },
  { id: uid(), day: 'Thursday', slot: '08:00 - 09:00', subject: 'Mathematics' },
  { id: uid(), day: 'Thursday', slot: '11:00 - 12:00', subject: 'English Literature' },
  { id: uid(), day: 'Friday', slot: '14:00 - 15:00', subject: 'Physics' },
  { id: uid(), day: 'Friday', slot: '17:00 - 18:00', subject: 'Computer Science' },
  { id: uid(), day: 'Saturday', slot: '10:00 - 11:00', subject: 'Mathematics' },
]

let schedule = []

export function initTimetable() {
  schedule = loadData('timetable', defaultSchedule)
  saveTimetable()
}

export function getSchedule() {
  return schedule
}

export function saveTimetable() {
  saveData('timetable', schedule)
}

export function addEntry(day, slot, subject) {
  schedule = schedule.filter((e) => !(e.day === day && e.slot === slot))
  schedule.push({ id: uid(), day, slot, subject })
  saveTimetable()
}

export function removeEntry(id) {
  schedule = schedule.filter((e) => e.id !== id)
  saveTimetable()
}

export function getEntry(day, slot) {
  return schedule.find((e) => e.day === day && e.slot === slot)
}

export function getDays() {
  return DAYS
}

export function getTimeSlots() {
  return TIME_SLOTS
}
